library(testthat)
library(RPresence)

test_check("RPresence")
