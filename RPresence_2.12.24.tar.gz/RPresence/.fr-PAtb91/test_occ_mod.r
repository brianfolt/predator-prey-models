library(RPresence)
setwd('h:/a/tmp')

paoname=system.file('extdata/skinks.pao',package="RPresence")
data<-read.pao(paoname)
data$unitcov$habitat[data$unitcov$Tussock==1]<-"tussock"
data$unitcov$habitat[data$unitcov$Pasture==1]<-"pasture"

m0<-occ.mod(model=list(psi~habitat,gamma~1,epsilon~1,p~1),data=data,type="do.1")
test_that("skinks AIC value", {
  expect_equal(round(m0$aic,3),1751.535)
})

# load a csv data file
filename<-system.file("extdata/twosp_exmpl.csv",package="RPresence")
csv<-read.csv(filename,as.is=T)
##  convert combined 2-sp format to "stacked" format
csv1=csv2=csv; 
csv1[csv==2]=0; csv1[csv1>1]=1
csv2[csv==1]=0; csv2[csv2>1]=1
dethist=rbind(csv1,csv2)
## 
nsites=nrow(dethist); nsrvys=ncol(dethist)         #  set number of sites,surveys from det. history data
dethist=matrix(as.integer(unlist(dethist)),nrow=nsites) # replace missing values (-) with NA

cov1=cov2=NULL

##          create input "pao" object, for use with occ.mod function
data=create.pao(dethist,unitcov=cov1,survcov=cov2,title="twosp example")


## fit some models
mod1<-occ.mod(model=list(psi~SP,p~SP),data=data,type="so.2sp.1",param="PsiBA")
cat('\nAIC=',mod1$aic,'\n')
test_that("two-species AIC value", {
  expect_equal(round(mod1$aic,4), 1167.2695)
})

