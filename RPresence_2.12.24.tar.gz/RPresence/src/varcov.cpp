#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "SingAnal.h"

    double xxLike(double *Params, int NPar);

void varcov(double xxLike(double *p, int N), double *Params, int NPar, double **covar) {
    /*      SUBROUTINE covar computes the var-covar matrix using 
       Finite-difference Approximations of Derivatives (Central difference approximations)*/
    extern TSingSpec SingSpec; FILE *g; g=SingSpec.g;
	int InvertMatrix(double **a, int n);
    int ii,jj ; time_t t1,t2; double ETA=.1e-12, eps; //double ETA=.1e-19, eps;
    double fHiHj, fHihj, fhiHj, fhihj, fx, f2H, fH, f2h, fh;
    double *h,**Par;    h = new double[NPar+2]; Par=new double*[NPar+1];
	for (ii=0; ii<=NPar; ii++) Par[ii]=new double[NPar+1];
    eps=pow(ETA, 1.0/3.0);  //  ETA=machine precision (smallest x, such that x+1 not = 1)
    eps=pow(pow(10.0, -SingSpec.LikeNRSig), 1.0/3.0);
    if (SingSpec.Verbose>1) fprintf(g,"LikeNRSig=%d eps=%g ETA=%g\n",SingSpec.LikeNRSig,eps,ETA);
	
	double *save_expval; save_expval=new double[SingSpec.N];
	for (ii=0; ii<SingSpec.N; ii++) save_expval[ii]=SingSpec.expval[ii];

    for (ii=0; ii<NPar; ii++) {
		Par[0][ii]=Params[ii]; h[ii] = eps*(1.0+fabs(Par[0][ii]));
        if (SingSpec.Verbose>1) fprintf(g,"h(%d)=%e parm(%d)=%e\n",ii,h[ii],ii,Par[0][ii]);
    }
    // set up covariance matrix of beta parameters
    time(&t1); if (SingSpec.Verbose>0) printf("Computing varcov matrix...\n");
    if (SingSpec.novar>1) {
      for (ii=0; ii<NPar; ii++) {  
	    if (SingSpec.Verbose>0) printf("computing row %d/%d...\n",ii+1,NPar);
        for (jj=0; jj<NPar; jj++) { Par[ii+1][jj] = Par[0][jj]; }
        fx = xxLike(Par[0], NPar);
        Par[ii+1][ii] = Par[0][ii] + 2*h[ii]; f2H = xxLike(Par[ii+1], NPar);
        Par[ii+1][ii] = Par[0][ii] + h[ii];    fH = xxLike(Par[ii+1], NPar);
        Par[ii+1][ii] = Par[0][ii] - 2*h[ii]; f2h = xxLike(Par[ii+1], NPar);
        Par[ii+1][ii] = Par[0][ii] - h[ii];    fh = xxLike(Par[ii+1], NPar);
        covar[ii][ii] = (-f2H + 16.0*fH - 30.0*fx + 16.0*fh - f2h) / (12.0*h[ii]*h[ii]);
        fHiHj = ((fH-fx)/h[ii] - (fx-fh)/h[ii])/h[ii];
        Par[ii+1][ii] = Par[0][ii];
        for (jj=ii+1; jj<NPar; jj++) {
            Par[ii+1][ii] = Par[0][ii] + h[ii];
            Par[ii+1][jj] = Par[0][jj] + h[jj];
            fHiHj = xxLike(Par[ii+1], NPar);      
            Par[ii+1][ii] = Par[0][ii] + h[ii];
            Par[ii+1][jj] = Par[0][jj] - h[jj];
            fHihj = xxLike(Par[ii+1], NPar);      
            Par[ii+1][ii] = Par[0][ii] - h[ii];
            Par[ii+1][jj] = Par[0][jj] + h[jj];
            fhiHj = xxLike(Par[ii+1], NPar);      
            Par[ii+1][ii] = Par[0][ii] - h[ii];
            Par[ii+1][jj] = Par[0][jj] - h[jj];
            fhihj = xxLike(Par[ii+1], NPar);
            Par[ii+1][ii] = Par[0][ii];
            Par[ii+1][jj] = Par[0][jj];
            covar[jj][ii]=covar[ii][jj]= (fHiHj - fHihj - fhiHj + fhihj) / (4*h[ii]*h[jj]);
        }
        if (covar[ii][ii]==0.) covar[ii][ii]=eps;
        time(&t2); 
        if (difftime(t2,t1)>2.0) { 
            if (SingSpec.Verbose>0) printf("%1.0f%% done (%d/%d)\r",ii*100/(double)NPar,ii,NPar); 
            t1=t2; 
        }
      }
	}
    delete[] h; if (SingSpec.Verbose>0) printf("100%% done           \n");
    if (SingSpec.Verbose>1) {
        fprintf(g,"hessian from varcov:\n");
        for (ii=0; ii<NPar; ii++) {
            for (jj=0; jj<NPar; jj++) fprintf(g," %e",covar[ii][jj]);
            fprintf(g,"\n");
        }
    }
	for (ii=0; ii<SingSpec.N; ii++) SingSpec.expval[ii]=save_expval[ii];
	ii=InvertMatrix(covar,NPar);
	for (ii=0; ii<NPar; ii++) for (jj=0; jj<NPar; jj++) SingSpec.finalVCmat[ii][jj]=covar[ii][jj];
	delete[] save_expval;	for (ii=0; ii<=NPar; ii++) delete[] Par[ii]; delete[] Par;
	//SingSpec.finalVCmat=covar;
}

