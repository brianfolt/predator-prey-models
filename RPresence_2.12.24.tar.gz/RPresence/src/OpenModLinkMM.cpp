#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "SingAnal.h"
//#define DBG 0

double OpenModLinkMM(double *Params, int NPars) {
    
    double OpenLikeMM(double ****Phi, double ***theta, double ***closedp, double ***closedp10, double ***closedb, double *pi);
    extern TSingSpec SingSpec;
    double getParam(int param_num, int param_grp, int row, int site, int srvy, double *Params, int transf, int LinkFn);
    int i,iie,iig,site, seasn,srvy, isrvy, iseasn, pstart, pistrt, gstrt, igrp, ngrps, 
	    N=SingSpec.N, T=SingSpec.T, PrmyPeriods=SingSpec.PrmyPeriods;
    double temp=0.0, eps, psiseasn, prdq, **qstar, cp, ***closedp10, ***closedb, *pi, pnlty=0.;
#ifdef DBG
    printf("OpenModLink...(model=%d)\n",SingSpec.Model);
    printf("params:"); for (i=0; i<NPars; i++) printf(" %f",Params[i]); printf("\n");
#endif
    pstart=SingSpec.NrowsDM[0];
    closedb   = new double**[N];  //   prob(detection is 'sure')
    closedp10 = new double**[N];  //   false-pos detection prob.
    qstar     = new double*[N];   //   compute qstar = 1 - pstar, where pstar =prob(detect at least once in a season)
    ngrps=1; if (SingSpec.NrowsDM[4]>0) ngrps=2;
    pi = new double[T]; 
	for (site=0; site<N; site++) {
		qstar[site]=new double[T]; closedb[site]=new double*[T]; closedp10[site]=new double*[T];
		for (srvy=0; srvy<T; srvy++) { 
			closedb[site][srvy]=new double[2]; closedp10[site][srvy]=new double[2];
			closedb[site][srvy][0]=closedb[site][srvy][1]=closedp10[site][srvy][0]=closedp10[site][srvy][1]=0;
		}
	}
	pistrt=SingSpec.NrowsDM[0]+SingSpec.NrowsDM[1]+SingSpec.NrowsDM[2]+SingSpec.NrowsDM[3];
    for (srvy=0; srvy<PrmyPeriods; srvy++) { //  only allow 2 groups : pi,1-pi
        pi[srvy]=1;
        if (SingSpec.NrowsDM[4]>0) pi[srvy]=getParam(pistrt+srvy,4,srvy,0,0,Params,0,SingSpec.LinkFn);
    }
    for (site=0; site<N; site++) {
		if (SingSpec.NMethods>1)  
			for (iseasn=i=0; iseasn<SingSpec.PrmyPeriods; iseasn++) {
				for (isrvy=srvy=0; isrvy<(SingSpec.NMethods*SingSpec.SecPeriods[iseasn]); isrvy++,srvy++)
					if ((srvy % SingSpec.NMethods) == 0) { 
						SingSpec.theta[site][i][0]=getParam(i+1,0,i+1,site,srvy,Params,0,SingSpec.LinkFn); i++;
					}
				}
        for (srvy=isrvy=seasn=0,prdq=1.; srvy<T; srvy++) {    //   isrvy = survey within season                                 
            for (igrp=0; igrp<ngrps; igrp++) {
                SingSpec.closedp[site][srvy][igrp] = cp = 0;
                if (SingSpec.Data[site][srvy]!=-1) { // if not missing data(site site, srvy srvy...
                    gstrt=T*(igrp);
                    cp = getParam(pstart+gstrt+srvy,1,gstrt+srvy,site,srvy,Params,0,SingSpec.LinkFn);
                    SingSpec.closedp[site][srvy][igrp] = cp;
                    if (SingSpec.FalsePos) { printf("\n*********  error - falsepos not ready yet!\n*******\n\n");
                        closedp10[site][srvy][igrp]=getParam(pstart+srvy+T,1,srvy+T,site,srvy,Params,0,SingSpec.LinkFn);
                        closedb[site][srvy][igrp]=getParam(pstart+srvy+T+T,1,srvy+T+T,site,srvy,Params,0,SingSpec.LinkFn);
                    }
                }
                prdq*=(1.-cp);    //   variables needed for autologistic model...
                if (igrp==0) 
                    if (++isrvy == (SingSpec.NMethods*SingSpec.SecPeriods[seasn])) { 
                        qstar[site][seasn]=prdq; isrvy=0; prdq=1; seasn++;  // qstar=prd of q's
                    }
            }
        }
    } 
	iie=SingSpec.NrowsDM[0]+SingSpec.NrowsDM[1]; iig=iie+SingSpec.NrowsDM[2];
    for (site=0; site<N; site++) { 
        // calculate psi
        SingSpec.Phi[site][0][0][0] = getParam(0,0,0,site,0,Params,0,SingSpec.LinkFn);     //                Occ  [  psi     1-psi ]
        SingSpec.Phi[site][0][1][0] = 1.0-SingSpec.Phi[site][0][0][0];                     // initial PHI:   Unocc[  0         0   ]
		SingSpec.Phi[site][1][0][0] = SingSpec.Phi[site][1][1][0] = 0.0;                   //
        psiseasn=SingSpec.Phi[site][0][0][0];                                              //
        for (seasn=1; seasn<PrmyPeriods; seasn++) {
            // calculate epsilon
            eps = getParam(iie+seasn-1,2,seasn-1,site,seasn-1,Params,0,1);
            if (SingSpec.Alt_Param_Checked) eps=1-eps;  // alt-parm: use persistance instead of extinction
            SingSpec.Phi[site][0][0][seasn] = 1.0 - eps;                                         //                        Occ     Unocc
            SingSpec.Phi[site][0][1][seasn] = eps;                                               //               Occ  [  1-eps     eps   ]
            // calculate gamma                                                                              Phi:  Unocc[   gam      1-gam ]
            SingSpec.Phi[site][1][0][seasn] = getParam(iig+seasn-1,3,seasn-1,site,seasn-1,Params,0,1); // 
            SingSpec.Phi[site][1][1][seasn] = 1.0 - SingSpec.Phi[site][1][0][seasn];             //
            //   calc psi(t+1) and set 1000'th site covar to this (to use psi(t) as covar in eps or gam)
            psiseasn=psiseasn*SingSpec.Phi[site][0][0][seasn]+(1.-psiseasn)*SingSpec.Phi[site][1][0][seasn]; 
        }
    }  // end site loop
#ifdef DBG
    fprintf(SingSpec.g,"%f %f %f %f %f %f %f %f %f %f %f",SingSpec.Phi[0][0][0][0],SingSpec.Phi[0][1][0][1],
         SingSpec.Phi[0][1][0][2],SingSpec.Phi[0][1][0][3],SingSpec.Phi[0][1][0][4],
         SingSpec.Phi[0][1][0][5],SingSpec.Phi[0][0][1][1],SingSpec.Phi[0][0][1][2],
         SingSpec.Phi[0][0][1][3],SingSpec.Phi[0][0][1][4],SingSpec.Phi[0][0][1][5]);
    fprintf(SingSpec.g," %f %f %f\n",SingSpec.closedp[0][0],SingSpec.closedp[0][1],SingSpec.closedp[0][2]);
    printf("calling OpenLike...\n");
#endif
    if (temp == 0.0) temp = pnlty+OpenLikeMM(SingSpec.Phi, SingSpec.theta, SingSpec.closedp, closedp10, closedb, pi);
    
    if (SingSpec.Verbose) printf("like=%f\n",temp);
    
    for (site=0; site<N; site++) {
        for (srvy=0; srvy<T; srvy++) {
            delete [] closedp10[site][srvy]; delete[] closedb[site][srvy];
        }
        delete [] closedp10[site]; delete [] closedb[site];
        delete [] qstar[site];
    }
    delete [] qstar; delete [] closedp10; delete [] closedb; delete [] pi;
    return (temp); 
}
