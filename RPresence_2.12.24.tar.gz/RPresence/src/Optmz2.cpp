#include <math.h>
#include <stdio.h>
#include <stdlib.h>
void optmz2(double *a, int n, double *z, double sig, double *w, int *irx, int mk, double eps) {
/*
C  *DECK OPTMZ2
C     SUBROUTINE OPTMZ2 IS CALLED BY OPTMIZ WHEN MAXIMIZING THE LOG-LIKELIHOOD FUNCTION.
 */
    int i,j,ii,jj,ij,mm=0;  double ti,v,tim=1/sig,al,r,b,gm,y;	//printf("optmz2...\n");

    if (n<=1) {
      a[1]+=sig*z[1]*z[1]; *irx=1; if (a[1]>0) return;
      a[1]=0; *irx=0; 
	  return;
	}
	if (sig==0 || *irx==0) return;
	if (sig<0) {

      ti=1/sig; jj=0;
      if (mk!=0) {       //                             L*W = Z ON INPUT
          for (j=1; j<=n; j++) {jj+=j; if (a[jj]!=0) ti+=(w[j]*w[j]/a[jj]); }
      }
      else {
          for (j=1; j<=n; j++) w[j]=z[j];
          for (j=1; j<=n; j++) {
              jj+=j; v=w[j];
              if (a[jj]<=0) w[j]=0;
              else {
                  ti+=(v*v)/a[jj];
                  if (j!=n) {
                      ij=jj;
                      for (i=j+1; i<=n; i++) { ij+=(i-1); w[i]-=v*a[ij]; }
                  }
              }
          }
      }
      //   SET TI, TIM AND W
	  if (*irx<=0) { 
	    ti=0; *irx=(-*irx-1); tim=ti; ii=jj; i=n; mm=1;
        for (j=1; j<=n; j++) {
          if (a[ii]!=0) tim=ti-(w[i]*w[i])/a[ii];
          w[i]=ti; ti=tim; ii-=i; i--;
        }
	  }
	  else 
	    if (ti>0) { 
          ti=eps/sig; if (eps==0) (*irx)--; tim=ti; ii=jj; i=n; mm=1;
          for (j=1; j<=n; j++) {
            if (a[ii]!=0) tim=ti-(w[i]*w[i])/a[ii];
            w[i]=ti; ti=tim; ii-=i; i--;
          }
	    }
        else 
		    if ((mk-1)<=0) { mm=0; tim=1/sig;}
	}

    jj=0;   //              UPDATE A   x140
    for (j=1; j<=n; j++) {
        jj+=j; ij=jj; v=z[j]; //       UPDATE A(J,J)
        if (a[jj]>0) {
		  al=v/a[jj]; ti=w[j]; if (mm==0) ti=tim+v*al;
          r=ti/tim; a[jj]*=r; if (r==0 || j==n) break;
          //                   UPDATE REMAINDER OF COL J
          b=al/ti;
          if (r<=4) for (i=j+1; i<=n; i++) { ij+=(i-1); z[i]-=v*a[ij]; a[ij]+=b*z[i];}
          else for (gm=tim/ti, i=j+1; i<=n; i++) { ij+=(i-1); y=a[ij]; a[ij]=b*z[i]+y*gm;	z[i]-=v*y;}
          tim=ti;
		} else {
          if (*irx>0 || sig<0 || v==0) ti=tim; 
		  else {
            *irx=1-*irx; a[jj]=v*v/tim;
            if (j==n) return;
            for (i=j+1; i<=n; i++) { ij+=(i-1); a[ij]=z[i]/v; }
            return;
		  }
		}
    }
    *irx=abs(*irx);
}
