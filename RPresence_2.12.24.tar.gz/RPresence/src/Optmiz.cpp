#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "SingAnal.h"
#define MAX(a,b) (a>b?a:b)

    double xxLike(double *Params, int NPar);

int optmiz(double xxLike(double *p, int N), int n, int nsig, int maxfn, int iopt, double *x, double *h, double *g, double *rf, double *w) {
    /*      SUBROUTINE OPTMIZ MAXIMIZES THE LOG LIKELIHOOD FUNCTION
C     SUBROUTINE OPTMZ2 IS CALLED.
C     FUNCTION            - A QUASI-NEWTON ALGORITHM FOR FINDING THE
C                           MINIMUM OF A FUNCTION OF N VARIABLES.
C     USAGE               - CALL OPTMIZ(FUNCT,N,NSIG,MAXFN,IOPT,X,H,G,F,W,IER)
C     PARAMETERS   FUNCT  - A USER SUPPLIED SUBROUTINE WHICH CALCULATES
C                           THE FUNCTION F FOR GIVEN PARAMETER VALUES
C                           X(1),X(2),...,X(N).
C                           THE CALLING SEQUENCE HAS THE FOLLOWING FORM
C                           CALL FUNCT(N,X,F)
C                           WHERE X IS A VECTOR OF LENGTH N.
C                           FUNCT MUST APPEAR IN AN EXTERNAL STATEMENT
C                           IN THE CALLING PROGRAM. FUNCT MUST NOT
C                           ALTER THE VALUES OF X(I),I=1,...,N OR N.
C                N      - THE NUMBER OF PARAMETERS (I.E., THE LENGTH
C                           OF X) (INPUT)
C                NSIG   - CONVERGENCE CRITERION. (INPUT). THE NUMBER
C                           OF DIGITS OF ACCURACY REQUIRED IN THE
C                           PARAMETER ESTIMATES.
C                           THIS CONVERGENCE CONDITION IS SATISIFIED IF
C                           ON TWO SUCCESSIVE ITERATIONS, THE PARAMETER
C                           ESTIMATES (I.E.,X(I), I=1,...,N) AGREE,
C                           COMPONENT BY COMPONENT, TO NSIG DIGITS.
C                MAXFN  - MAXIMUM NUMBER OF FUNCTION EVALUATIONS (I.E.,
C                           CALLS TO SUBROUTINE FUNCT) ALLOWED. (INPUT)
C                IOPT   - INPUT OPTIONS SELECTOR.
C                         IOPT = 0 CAUSES OPTMIZ TO INITIALIZE THE
C                           HESSIAN MATRIX H TO THE IDENTITY MATRIX.
C                X      - VECTOR OF LENGTH N CONTAINING PARAMETER
C                           VALUES.
C                         ON INPUT, X MUST CONTAIN THE INITIAL
C                           PARAMETER ESTIMATES.
C                         ON OUTPUT, X CONTAINS THE FINAL PARAMETER
C                           ESTIMATES AS DETERMINED BY OPTMIZ.
C                H      - VECTOR OF LENGTH N*(N+1)/2 CONTAINING AN
C                           ESTIMATE OF THE HESSIAN MATRIX
C                           D**2F/(DX(I)DX(J)), I,J=1,...,N.
C                           H IS STORED IN SYMMETRIC STORAGE MODE.
C                         ON INPUT, IF IOPT = 0, OPTMIZ INITIALIZES H
C                           TO THE IDENTITY MATRIX. AN INITIAL SETTING
C                           OF H BY THE USER IS INDICATED BY IOPT=1.
C                           H MUST BE POSITIVE DEFINITE. IF IT IS NOT,
C                           A TERMINAL ERROR OCCURS.
C                         ON OUTPUT, H CONTAINS AN ESTIMATE OF THE
C                           HESSIAN AT THE FINAL PARAMETER ESTIMATES
C                           (I.E., AT X(1),X(2),...,X(N))
C                G      - A VECTOR OF LENGTH N CONTAINING AN ESTIMATE
C                           OF THE GRADIENT DF/DX(I),I=1,...,N AT THE
C                           FINAL PARAMETER ESTIMATES. (OUTPUT)
C                F      - A SCALAR CONTAINING THE VALUE OF THE FUNCTION
C                           AT THE FINAL PARAMETER ESTIMATES. (OUTPUT)
C                W      - A VECTOR OF LENGTH 3*N USED AS WORKING SPACE.
C                         ON OUTPUT, WORK(I), CONTAINS FOR
C                           I = 1, THE NORM OF THE GRADIENT (I.E.,
C                             SQRT(G(1)**2+G(2)**2+...+G(N)**2))
C                           I = 2, THE NUMBER OF FUNCTION EVALUATIONS
C                             PERFORMED.
C                           I = 3, AN ESTIMATE OF THE NUMBER OF
C                             SIGNIFICANT DIGITS IN THE FINAL
C                             PARAMETER ESTIMATES.
C                IER    - ERROR PARAMETER.
C                         IER = 0 IMPLIES THAT CONVERGENCE WAS
C                           ACHIEVED AND NO ERRORS OCCURRED.
C                         TERMINAL ERROR
C                           IER = 129 IMPLIES THAT THE INITIAL HESSIAN
C                             MATRIX IS NOT POSITIVE DEFINITE. THIS
C                             CAN OCCUR ONLY FOR IOPT = 1.
C                           IER = 130 IMPLIES THAT THE ITERATION WAS
C                             TERMINATED DUE TO ROUNDING ERRORS
C                             BECOMING DOMINANT. THE PARAMETER
C                             ESTIMATES HAVE NOT BEEN DETERMINED TO
C                             NSIG DIGITS.
C                           IER = 131 IMPLIES THAT THE ITERATION WAS
C                             TERMINATED BECAUSE MAXFN WAS EXCEEDED.
C     PRECISION           - SINGLE
C     REQD.  ROUTINES     - OPTMZ2
C*/

    double hh,eps,hjj,v,df,relx=0,gs0=0,diff,aeps=0,alpha=0,ff=0,tot,f=0,f1=0,f2=0,z,gys,dgs,sig,zz,gnrm;
    int i,j,ij,ir,nm1,np1,jj,l,kj,ig,jp1,jb,idiff=1,igg,is,k,ii,im1,nj,ier=0,jnt;
    double reps=1.45519152284e-11, ax=0.1, p1=0.1;
    extern TSingSpec SingSpec;
    SingSpec.optmiz_done=0;

    void optmz2(double *a, int n, double *z, double sig, double *w, int *ir, int mk, double eps);
    SingSpec.ifn=0; hh=sqrt(reps); eps=pow(10,(double)-nsig); ig=n; igg=n+n; is=igg; ir=n;
    w[1]=-1; w[2]=w[3]=0;

    for (ij=0, i=1; i<=n; i++) {  // SET H TO THE IDENTITY MATRIX
        for (j=1; j<=i; j++) h[++ij]=0;
        h[ij]=1;
    }

    f=xxLike(x+1,n); SingSpec.ifn=1; df=-1;//    EVALUATE FUNCTION AT STARTING POINT
x110:
        //  EVALUATE GRADIENT W(IG+I),I=1,...,N
    if (idiff==2) { //goto x480;
	  for (i=1; i<=n; i++) {
        z=hh*MAX(fabs(x[i]),ax); zz=x[i]; x[i]=zz+z;  f1=xxLike(x+1,n); x[i]=zz-z;
        f2=xxLike(x+1,n); SingSpec.ifn+=2; w[ig+i]=(f1-f2)/(z+z); x[i]=zz;
      }	
	} else {
      for (i=1; i<=n; i++) {
        z=hh*MAX(fabs(x[i]),ax); zz=x[i]; x[i]=zz+z; f1=xxLike(x+1,n); SingSpec.ifn++; w[ig+i]=(f1-f)/z; x[i]=zz; 
      } 
	}
    if(SingSpec.Verbose>0)printf(">>>>%5d %f            \r",SingSpec.ifn,f1); 	
x120:       // BEGIN ITERATION LOOP
    if (SingSpec.ifn>=maxfn) {ier=131; goto x410;};
    for (i=1; i<=n; i++) w[i]=-w[ig+i];
    if (ir>=n) {
      //  DETERMINE SEARCH DIRECTION W BY SOLVING H*W = -G WHERE H = L*D*L-TRANSPOSE
      g[1]=w[1];
      if (n>1) {
		for (ii=1, i=2; i<=n; i++) {  //  SOLVE L*W = -G
          ij=ii; ii+=i; v=w[i]; im1=i-1;
          for (j=1; j<=im1; j++) v-=h[++ij]*w[j];
          g[i]=v; w[i]=v;
        }
        w[n]/=h[ii];  // SOLVE (D*LT)*Z = W WHERE LT = L-TRANSPOSE
        jj=ii; nm1=n-1;
        for (nj=1; nj<=nm1; nj++) {
          j=n-nj; jp1=j+1; jj-=jp1; 
          v=w[j]/h[jj]; ij=jj;
          for (i=jp1; i<=n; i++) { ij+=i-1; v-=h[ij]*w[i]; }
          w[j]=v;
        }
	  } else  w[1]/=h[1];
	}
    relx=0; gs0=0;
    for (i=1; i<=n; i++) {
        w[is+i]=w[i]; 
        diff=fabs(w[i])/MAX(fabs(x[i]),ax);
        relx=MAX(relx,diff); gs0+=w[ig+i]*w[i];
    }
    if (relx==0) goto x400;
    aeps=eps/relx; ier=130;
    if (gs0>=0 || df==0) goto x400;
    ier=0; alpha=(-df-df)/gs0;
    if (alpha<=0 || alpha>1) alpha=1;
    if (idiff==2) alpha=MAX(p1,alpha);
    ff=f; tot=0; jnt=0;
x210:
    if (SingSpec.ifn>=maxfn) {ier=131; goto x410;};
    for (i=1; i<=n; i++) w[i]=x[i]+alpha*w[is+i];
    f1=xxLike(w+1,n); SingSpec.ifn++; if(SingSpec.Verbose>0)printf(">%5d %f  %f              \r",SingSpec.ifn,f1,f); 
    if (f1>=f) { 
      if (f==ff && idiff==2 && relx>eps) ier=130;
      if (alpha<aeps) goto x400;
      if (SingSpec.ifn>=maxfn) {ier=131; goto x410;};
      alpha=0.5*alpha;
      for (i=1; i<=n; i++) w[i]=x[i]+alpha*w[is+i];
      f2=xxLike(w+1,n); SingSpec.ifn++; if(SingSpec.Verbose>0)printf(">>>%5d %f          \r",SingSpec.ifn,f2); 
      if (SingSpec.ifn>=maxfn) {ier=131; goto x410;};
      if (f2>=f) {
        z=p1; if ((f1+f)>(f2+f2)) z=1+0.5*(f-f1)/(f+f1-f2-f2);
        z=MAX(p1,z); alpha*=z; jnt=1;
        goto x210;
	  }
      tot+=alpha; ier=0; f=f2;
      for (i=1; i<=n; i++) x[i]=w[i];
      if (tot<aeps) goto x400; else goto x320;	
	}
    f2=f; tot+=alpha;
x230:
    ier=0; f=f1; for (i=1; i<=n; i++) x[i]=w[i];
    if ((jnt-1)==0) {
		if (tot<aeps) goto x400; else goto x320;
	}
    if ((jnt-1)>0) goto x320;
    if (SingSpec.ifn>=maxfn) {ier=131; goto x410;};
    for (i=1; i<=n; i++)  w[i]=x[i]+alpha*w[is+i];
    f1=xxLike(w+1,n); SingSpec.ifn++; if(SingSpec.Verbose>0)printf(">>%5d %d %f            \r",SingSpec.ifn,maxfn,f1); 
    if (SingSpec.ifn>=maxfn) {ier=131; goto x410;};
    if (f1>=f) goto x320;
    if ((f1+f2)>=(f+f) && (7*f1+5*f2)>(12*f)) jnt=2;
    tot+=alpha; alpha+=alpha;
    goto x230;

x320:
    alpha=tot;
    for (i=1; i<=n; i++) w[i]=w[ig+i]; //  SAVE OLD GRADIENT
       // EVALUATE GRADIENT W(IG+I), I=1,...,N
	if (idiff==2) { 
	  for (i=1; i<=n; i++) {
        z=hh*MAX(fabs(x[i]),ax); zz=x[i]; x[i]=zz+z;  f1=xxLike(x+1,n); x[i]=zz-z;
        f2=xxLike(x+1,n); SingSpec.ifn+=2; w[ig+i]=(f1-f2)/(z+z); x[i]=zz;
      }	
	} else {
      for (i=1; i<=n; i++) {
        z=hh*MAX(fabs(x[i]),ax); zz=x[i]; x[i]=zz+z; f1=xxLike(x+1,n); SingSpec.ifn++; w[ig+i]=(f1-f)/z; x[i]=zz; 
      } 
	}
    if(SingSpec.Verbose>0)printf(">>>>%5d %f            \r",SingSpec.ifn,f1); 

    if (SingSpec.ifn>=maxfn) {ier=131; goto x410;};
    gys=0;
    for (i=1; i<=n; i++) { gys+=w[ig+i]*w[is+i]; w[igg+i]=w[i]; }
    df=ff-f; dgs=gys-gs0;
    if (dgs>0) { 
      if ((dgs+alpha*gs0)>0) { //    UPDATE HESSIAN USING DFP FORMULA
        zz=alpha/(dgs-alpha*gs0);  sig=-zz;  optmz2(h,n,w,sig,g,&ir,0,reps);  z=dgs*zz-1;
        for (i=1; i<=n; i++) g[i]=w[ig+i]+z*w[igg+i];
        sig=1/(zz*dgs*dgs); optmz2(h,n,g,sig,w,&ir,0,0);	
	  } else {
        sig=1/gs0; ir=-ir;  optmz2(h,n,w,sig,g,&ir,0,0);  //  UPDATE HESSIAN H USING COMPLEMENTARY DFP FORMULA
        for (i=1; i<=n; i++) g[i]=w[ig+i]-w[igg+i];
        sig=1/(alpha*dgs); ir=-ir; optmz2(h,n,g,sig,w,&ir,0,0);
	  }
	}
    goto x120;
x400:
    if (idiff!=2) { idiff=2; goto x110;} //                CHANGE TO CENTRAL DIFFERENCES
x410:
    if (relx>eps && ier==0) goto x110;
    //             MOVE GRADIENT TO G AND RETURN
    for (gnrm=0, i=1; i<=n; i++) { g[i]=w[ig+i]; gnrm+=g[i]*g[i]; }
    w[1]=sqrt(gnrm); w[2]=SingSpec.ifn; w[3]=-log10(MAX(reps,relx));
    if(SingSpec.Verbose>1)printf("norm(gradient)=%f No. function calls: %f  No sig digits:%f\n",w[1],w[2],w[3]);
    //             COMPUTE H = L*D*L-TRANSPOSE
    if (n!=1) {  
      np1=n+1; nm1=n-1; jj=n*np1/2;
      for (jb=1; jb<=nm1; jb++) {
          jp1=np1-jb; jj-=jp1; hjj=h[jj]; ij=jj; l=0;
          for (i=jp1; i<=n; i++) {
              l++; ij+=(i-1); v=h[ij]*hjj; kj=ij;
              for (k=i; k<=n; k++) { h[kj+l]+=h[kj]*v; kj+=k; }
              h[ij]=v;
          }
          hjj=h[jj];
      }
	}
	//printf("\n *** ERROR MESSAGE IER=%d FROM ROUTINE OPTMIZ\n",ier);
	//printf("500 #=%d %18.12f %18.12f %18.12f %18.12f\n",SingSpec.ifn,alpha,aeps,relx,eps);
    *rf=f; 
    if(SingSpec.Verbose>0) printf("\noptmiz done... %1.0f iterations, %3.2f sig.digits.        \n",w[2],w[3]);
	SingSpec.optmiz_done=1;	for (i=0; i<n; i++) SingSpec.finalBetaEst[i]=x[i+1];
    return(ier);
}

void try_optmz_randiv(double (*xxLinkFn)(double Params[], int npar), int NPar, double *Params, double *Work, double *Hess, double *LL) {
	//         try optimization routine with user-specified number of random initial value vectors
	//         and save results from vector which gave the maximum log-likelihood
	double Random(void);
    int optmiz(double xxlike(double *Params, int NPar),int NPar, int Sig, int MaxFN, int iopt, double *Params, double *Hess, double *Grad, double *LL, double *Work);
	
    extern TSingSpec SingSpec; FILE *g; g=SingSpec.g; //	MSOpenLinkFn=&MSOpenLink; 
	
	double *Grad1, *iv, *bestIV, minLL=9e44, maxLL=-9e44, *LLsv, LLscale=1; 
	int i,j,kk,itry,mx=1, *LLhist, hist_size=20; 
	Grad1 = new double[NPar+1]; iv=new double[NPar]; bestIV=new double[NPar];  
	LLsv=new double[SingSpec.nrandIV+1]; LLhist=new int[hist_size]; for (i=0; i<hist_size; i++) LLhist[i]=0;
	
	for (i=0; i<NPar; i++) iv[i]=bestIV[i]=Params[i];
	for (itry=0; itry<=SingSpec.nrandIV; itry++) {
	  if (itry>0) for (i=0; i<NPar; i++) iv[i]=Params[i]=Random()*10-5;
      optmiz(xxLinkFn,NPar, SingSpec.LikeNRSig, SingSpec.maxfn, 0, Params-1, Hess, Grad1, LL, Work); *LL=2*(*LL); LLsv[itry]=(*LL);
	  if (SingSpec.Verbose>0) printf("attempt %d/%d (iv=%5.2f %5.2f %5.2f...), optmiz done. -2loglike=%9.4f\n",itry,SingSpec.nrandIV,iv[0],iv[1],iv[2],*LL); 
	  fprintf(g,"attempt %d/%d (iv=%5.2f %5.2f %5.2f...), optmiz done. -2loglike=%9.4f\n",itry,SingSpec.nrandIV,iv[0],iv[1],iv[2],*LL); 
	  if (*LL < minLL) { minLL=*LL; for (i=0; i<NPar; i++) bestIV[i]=iv[i]; }
	  if (*LL > maxLL) maxLL=*LL;
	}
	if (SingSpec.nrandIV>0) {
	  LLscale=(maxLL-minLL)/(hist_size-1);
	  for (i=0; i<=SingSpec.nrandIV; i++) { j=floor((LLsv[i]-minLL)/LLscale); LLhist[j]++;}
	  for (i=0; i<hist_size; i++) if (LLhist[i]>mx) mx=LLhist[i];
	
      fprintf(g,"\nDistribution of -2logLike:\n");
      for (i=0; i<hist_size; i++) {
        fprintf(g,"%6.2f %5d:",minLL+i*LLscale,LLhist[i]);
        kk=LLhist[i]*50/mx; 
		if (kk>0) for (j=0; j<kk; j++) fprintf(g,"*"); fprintf(g,"\n");
        if (SingSpec.Verbose>0) printf("%6.2f %5d:",minLL+i*LLscale,LLhist[i]);
        if (kk>0) for (j=0; j<kk; j++) { if (SingSpec.Verbose>0) printf("*"); printf("\n");}
      }
	}
	for (i=0; i<NPar; i++) Params[i]=bestIV[i];
    optmiz(xxLinkFn,NPar, SingSpec.LikeNRSig, SingSpec.maxfn, 0, Params-1, Hess, Grad1, LL, Work); 
	SingSpec.finalLL=*LL; 
	SingSpec.finalBetaEst=Params; 
	
	if (SingSpec.Verbose>0) printf("%d random initial value vectors (+ default initial vector) attempted:\n",SingSpec.nrandIV);
	fprintf(g,"%d random initial value vectors attempted:\n",SingSpec.nrandIV);
	fprintf(g,"Initial values:\n"); 
	for (i=0; i<NPar; i++) { fprintf(g," %9.4f",bestIV[i]); if ((i%8)==7) fprintf(g,"\n"); }
	fprintf(g,"\n");
	delete[] iv; delete[] bestIV; delete[] Grad1;	 delete[] LLsv;
}
