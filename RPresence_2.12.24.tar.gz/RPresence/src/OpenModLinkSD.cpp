#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "SingAnal.h"
//#define DBG 1
#ifndef noRPRES
	#include <R_ext/PrtUtil.h>
    #define printf Rprintf
#endif

double OpenModLinkSD(double *Params, int NPars) {   
    double OpenLikeSD(double ****Phi, double ***closedp, double ***theta, double pi);
    extern TSingSpec SingSpec;
    double getParam(int param_num, int param_grp, int row, int site, int srvy, double *Params, int transf, int LinkFn);
    int i,site=0, seasn,srvy=0, isrvy, pstart, th0pistrt, pistrt, othrsite, pDM,
	    N=SingSpec.N, T=SingSpec.T, PrmyPeriods=SingSpec.PrmyPeriods;
    double temp=0.0, eps=0, pnlty=0.,pi=-1.,gam=0, *psi, denom, **qstar, x, qstar1, qstar2;
    psi = new double[N]; qstar = new double*[N];
#ifdef DBG
    printf("OpenModLinkSD...(model=%d)\n",SingSpec.Model); 
    printf("params:"); for (i=0; i<NPars; i++) printf(" %f",Params[i]); printf("\n");
#endif
    pstart=SingSpec.NrowsDM[0]+SingSpec.NrowsDM[1]+SingSpec.NrowsDM[2]; pDM=3; 
	if (SingSpec.NrowsDM[2]>0) 
		if (SingSpec.Realname[2][0][0]=='t') { pstart=SingSpec.NrowsDM[0]; pDM=1;}
	th0pistrt=pstart+SingSpec.NrowsDM[pDM]; 
	pistrt=th0pistrt+SingSpec.NrowsDM[pDM+2]; 
    if (SingSpec.NrowsDM[pDM+2]>0) pi=getParam(pistrt,pDM+2,0,site,srvy,Params,0,SingSpec.LinkFn);
    for (site=0; site<N; site++) { 
        SingSpec.theta[site][0][2]=0;  qstar[site]=new double[PrmyPeriods];//  prob(detect at least once in a year)
        if (SingSpec.NrowsDM[pDM+1]>0)   // get th0pi  (stored in theta[site][seasn][2])
			SingSpec.theta[site][0][2]=getParam(th0pistrt,pDM+1,0,site,0,Params,0,SingSpec.LinkFn);
		qstar1=qstar2=1;
        for (srvy=isrvy=seasn=0; srvy<T; srvy++) {  //   isrvy = survey within season
            SingSpec.closedp[site][srvy][0] =  SingSpec.closedp[site][srvy][1] = 0;
            SingSpec.theta[site][srvy][0]=getParam(1+srvy,0,1+srvy,site,srvy,Params,0,SingSpec.LinkFn);
            SingSpec.theta[site][srvy][1]=getParam(T+1+srvy,0,T+1+srvy,site,srvy,Params,0,SingSpec.LinkFn);
            if (SingSpec.Data[site][srvy]!=-1) { // if not missing data(site site, srvy srvy...
                SingSpec.closedp[site][srvy][0] = getParam(pstart+srvy,pDM,srvy,site,srvy,Params,0,SingSpec.LinkFn);
                if (pi>=0)
                    SingSpec.closedp[site][srvy][1] = getParam(pstart+srvy+T,pDM,srvy+T,site,srvy,Params,0,SingSpec.LinkFn);
            }
			qstar1*=(1-SingSpec.theta[site][srvy][0]+SingSpec.theta[site][srvy][0]*(1-SingSpec.closedp[site][srvy][0]));
			qstar2*=(1-SingSpec.theta[site][srvy][srvy==0]+SingSpec.theta[site][srvy][srvy==0]*(1-SingSpec.closedp[site][srvy][0]));
            if ((++isrvy == SingSpec.SecPeriods[seasn]) && srvy<(T-1)) {
                qstar[site][seasn]=(1-SingSpec.theta[site][seasn][2])*qstar1+SingSpec.theta[site][seasn][2]*qstar2; // (1-th0pi,th0pi) * q*
				isrvy=0; SingSpec.theta[site][++seasn][2]=0;    //   this is really th0pi(site,season)
                if (SingSpec.NrowsDM[pDM+1]>0) {
                    SingSpec.theta[site][seasn][2]=getParam(th0pistrt+seasn,pDM+1,seasn,site,seasn,Params,0,SingSpec.LinkFn);
				}
            }
        }
    } 
#ifdef DBG
    printf("closedp=%f %f pi=%f\n",SingSpec.closedp[0][0][0],SingSpec.closedp[0][0][1],pi); 
    printf("theta=%f %f %f\n",SingSpec.theta[0][0][0],SingSpec.theta[0][0][1],SingSpec.theta[0][0][2]); 
#endif
        //  last subscript for psibar below is always zero in this model.
    for (seasn=0; seasn<=PrmyPeriods; seasn++) for (site=0; site<N; site++) SingSpec.psibar[seasn][site][0]=0;
    for (site=seasn=0; site<N; site++) {
        // transition matrix, Phi =  [  psi    1-psi ]  for t=0   [  1-eps   eps ]  for t > 0
        //                           [  0        0   ]            [    gam  1-gam] 
        SingSpec.Phi[site][0][0][0] = getParam(0,0,0,site,0,Params,0,SingSpec.LinkFn);
        SingSpec.Phi[site][0][1][0] = 1.0-SingSpec.Phi[site][0][0][0]; 
        SingSpec.Phi[site][1][0][0] = SingSpec.Phi[site][1][1][0] = 0.0;
        psi[site] = SingSpec.Phi[site][0][0][seasn];
        if (SingSpec.uncondpsi==0 && SingSpec.OpenData[site][seasn]>=0) {  //   use conditional psi (if at least one non-missing data for season)
            if (SingSpec.OpenData[site][seasn]>0) psi[site]=1.;  //  detect at least once in a year
            else {
                denom=1.0-psi[site]+psi[site]*qstar[site][seasn];
                if (denom!=0) psi[site]=psi[site]*qstar[site][seasn]/denom;
            }
        }
        if (SingSpec.UseNeighbor>0)
            for (othrsite=0; othrsite<N; othrsite++) {
#ifdef neighbor2					
				i=SingSpec.neighbor_lst[othrsite][site]; if (i<0) break;
				SingSpec.psibar[seasn][othrsite][0]+=psi[site]*SingSpec.neighbor_wgt[i];
#else				
                if (SingSpec.neighbor[othrsite][site]>1) break;  //  any digit > 1 indicates no more neighbors for site
                x=(double)SingSpec.neighbor[othrsite][site]*SingSpec.neighbor_wgt[othrsite];
                SingSpec.psibar[seasn][othrsite][0]+=psi[site]*x; 
				//if (othrsite==0 && x>0) 
				//	printf("site=%d othersite=%d psi=%f x=%f psibar=%f opendata=%d q=%f\n",site,othrsite,psi[site],x,
				//    SingSpec.psibar[seasn][othrsite][0],SingSpec.OpenData[site][seasn],qstar[site][seasn]);
#endif
            }
	}
    for (seasn=1; seasn<PrmyPeriods; seasn++) {
		for (site=0; site<N; site++) {
            eps = getParam(T*2+PrmyPeriods-1+seasn,2,seasn-1,site,seasn-1,Params,0,1);
            if (SingSpec.Alt_Param_Checked) eps=1-eps;  // alt-parm: use persistance instead of extinction
            SingSpec.Phi[site][0][0][seasn] = 1.0 - eps; SingSpec.Phi[site][0][1][seasn] = eps;
            gam=SingSpec.Phi[site][1][0][seasn] = getParam(T*2+seasn,1,seasn-1,site,seasn-1,Params,0,1);  //  gamma
            SingSpec.Phi[site][1][1][seasn] = 1.0 - gam                   ;             //  1-gamma
            //   calc unconditional psi(site,seasn) and sum to get avg psi(seasn)
            psi[site]=  psi[site]*SingSpec.Phi[site][0][0][seasn]+   //  psi(j-1)*(1-eps(j))+
                  (1.-psi[site])*SingSpec.Phi[site][1][0][seasn];  //  (1-psi(j-1))*gam(j)
            if (SingSpec.uncondpsi==0) {  //   use conditional psi
                if (SingSpec.OpenData[site][seasn]>0) psi[site]=1.;
                else if (qstar[site][seasn]>0.) psi[site]=psi[site]*qstar[site][seasn]/(1.-psi[site]+psi[site]*qstar[site][seasn]);
            }
            if (SingSpec.UseNeighbor>0)
                //  add psi(site) to each of it's (othrsite) neighbors
                for (othrsite=0; othrsite<N; othrsite++) {
#ifdef neighbor2					
					i=SingSpec.neighbor_lst[othrsite][site]; if (i<0) break;
					SingSpec.psibar[seasn][othrsite][0]+=psi[site]*SingSpec.neighbor_wgt[i];
#else  					
                    if (SingSpec.neighbor[othrsite][site]>1) break;       // last subscript for psibar always zero for 1 species model
                    x=(double)SingSpec.neighbor[othrsite][site]*SingSpec.neighbor_wgt[othrsite]; //  othrsite is focal site, site is neighbr site
                    SingSpec.psibar[seasn][othrsite][0]+=psi[site]*x;
#endif
                }
        }
    }  // end site loop
	 for (i=0; i<N; i++)  delete [] qstar[i]; delete [] qstar; delete psi;
#ifdef DBG
    printf("calling OpenLikeSD...\n");
#endif
    if (temp == 0.0) temp = pnlty+OpenLikeSD(SingSpec.Phi, SingSpec.closedp, SingSpec.theta, pi);  
    return (temp); 
}
